package com.swayalgo.numbertowordsexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.justinclicks.numbertowords.NumberToWordConverter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView txt=findViewById(R.id.txt);

        NumberToWordConverter numberToWordConverter=new NumberToWordConverter();
        txt.setText(numberToWordConverter.convert(10505));


    }
}